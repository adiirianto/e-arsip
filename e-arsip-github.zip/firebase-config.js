const firebaseConfig = {
    apiKey: "ISI_API_KEY_MU",
    authDomain: "ISI_AUTH_DOMAIN_MU",
    databaseURL: "ISI_DATABASE_URL_MU",
    projectId: "ISI_PROJECT_ID_MU",
    storageBucket: "ISI_STORAGE_BUCKET_MU",
    messagingSenderId: "ISI_MESSAGING_SENDER_ID_MU",
    appId: "ISI_APP_ID_MU"
};
firebase.initializeApp(firebaseConfig);
